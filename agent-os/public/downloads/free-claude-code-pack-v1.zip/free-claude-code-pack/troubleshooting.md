# 🦉 Troubleshooting

Every error I hit while building Free Claude Code.

And the fix.

---

## ❌ "401 Unauthorized" in fcc-server logs

Cause: Claude CLI is using OAuth from your keychain, ignoring env vars.

Fix: add `--bare` to the claude command.

`--bare` forces strict env-var auth.

Without it, the OAuth from `claude login` wins.

Example:

```bash
claude --bare -p "say hi"
```

---

## ❌ "API Error: API returned an empty or malformed response (HTTP 200)"

Same root cause as above.

The proxy returned 200, but the CLI couldn't authenticate.

Fix: `--bare`.

---

## ❌ "MODULE_NOT_FOUND" from claude

Cause: a session-end hook tried to load a `hook-handler.cjs` that doesn't exist in your cwd.

Fix: run claude from `$HOME` or any dir that doesn't have a `.claude/helpers/` folder.

Cosmetic — doesn't affect the actual reply.

---

## ❌ "fcc-server not reachable on :8082"

Cause: proxy isn't running.

Check:

```bash
lsof -i :8082 -sTCP:LISTEN
```

If nothing listed: start it.

```bash
fcc-server
```

Or:

```bash
./start-fcc.sh --bg
```

---

## ❌ Owl Alpha takes forever to reply

That's normal.

OpenRouter free tier has rate limits.

Owl Alpha runs at ~12 tokens/sec.

A 200-token reply = 17 seconds.

A 1000-token reply = ~80 seconds.

If you need speed: swap to a faster model.

Edit `~/.fcc/.env`:

```
MODEL="open_router/deepseek/deepseek-chat-v3.1:free"
```

Restart fcc-server.

DeepSeek is ~5x faster than Owl Alpha.

Or pay $0.05/M tokens for `open_router/anthropic/claude-3-5-haiku` and get 50 tok/s.

---

## ❌ "Port 8082 already in use"

Something else is on 8082.

Find it:

```bash
lsof -i :8082 -sTCP:LISTEN
```

Kill it:

```bash
kill $(lsof -ti :8082 -sTCP:LISTEN)
```

Or run fcc-server on a different port:

```bash
PORT=8083 fcc-server
```

Then update Agent OS to point at 8083 (in `src/lib/fcc.ts` change `FCC_PORT = 8083`).

---

## ❌ Conversation history wipes when I navigate tabs

In Agent OS only.

Cause: React state is per-component-mount.

Fix already in: `FreeClaudePanel.tsx` uses `localStorage` for persistence.

Key: `agentic-os/freeclaude/history/v1`.

Wipe it in DevTools to start fresh.

---

## ❌ Each reply repeats itself twice

Cause: the Claude CLI emits both streaming deltas AND a final assistant message with the same content.

Fix already in: `FreeClaudePanel.tsx` uses a `sawDeltas` flag — if deltas came in, the final message is ignored.

If you see this in your own build: copy the parser logic from there.

---

## ❌ "openrouter says I have no credits"

You hit a free-tier limit.

Either:
- Wait an hour for the limit to reset
- Add $5 to your OpenRouter account ($5 unlocks higher limits for free models)
- Switch to a different free model

Check usage at: https://openrouter.ai/activity

---

## ❌ "I broke ~/.fcc/.env"

Recreate it:

```bash
mv ~/.fcc/.env ~/.fcc/.env.broken
fcc-init
```

Then paste your OpenRouter key + model back in.

Reference `env.template` in this pack if you need the layout.

---

## ❌ "I want to switch back to real Anthropic"

Two options:

1. Unset the env vars in your shell:
   ```bash
   unset ANTHROPIC_BASE_URL ANTHROPIC_API_KEY
   ```
   Now `claude` hits Anthropic directly again.

2. In Agent OS — the regular `Claude` sidebar entry already goes direct to Anthropic. Only `Free Claude Code` uses the proxy.

You can have both. They don't conflict.

---

## 🆘 Still stuck

Open an issue on the Free Claude Code repo:

https://github.com/Alishahryar1/free-claude-code/issues

Or drop me a message in AI Profit Boardroom.

I'll get back to you within a day.

— Julian
