# 🦉 Install — Free Claude Code

Copy-paste these in your terminal.

In order.

Don't skip steps.

---

## Step 1 · Get the prerequisites

You need:

- macOS or Linux (Windows works in WSL2)
- Python 3.14
- `uv` (the fast Python installer)
- Node 18+ (you probably have this if you've used Claude Code before)

Install `uv` if you don't have it:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Install Python 3.14:

```bash
uv python install 3.14
```

---

## Step 2 · Install Free Claude Code

One command:

```bash
uv tool install --force "git+https://github.com/Alishahryar1/free-claude-code.git"
```

That installs 4 commands:

- `fcc-server` (the proxy)
- `fcc-init` (creates default config)
- `fcc-claude` (launches Claude with the right env vars)
- `free-claude-code` (alias for fcc-server)

---

## Step 3 · Get a free OpenRouter API key

Go to: https://openrouter.ai/keys

Sign up.

Click `Create Key`.

Name it anything. `fcc` is fine.

Copy the key. Starts with `sk-or-v1-...`.

---

## Step 4 · Configure

First, create the default config:

```bash
fcc-init
```

That creates `~/.fcc/.env`.

Open it in your editor:

```bash
open ~/.fcc/.env
```

Or:

```bash
nano ~/.fcc/.env
```

Find this line:

```
OPENROUTER_API_KEY=""
```

Paste your OpenRouter key between the quotes.

Find this section:

```
MODEL_OPUS=
MODEL_SONNET=
MODEL_HAIKU=
MODEL="nvidia_nim/nvidia/nemotron-3-super-120b-a12b"
```

Replace it with this:

```
MODEL_OPUS="open_router/openrouter/owl-alpha"
MODEL_SONNET="open_router/openrouter/owl-alpha"
MODEL_HAIKU="open_router/openrouter/owl-alpha"
MODEL="open_router/openrouter/owl-alpha"
```

Save.

Close.

---

## Step 5 · Start the proxy

In a fresh terminal:

```bash
fcc-server
```

You should see:

```
INFO:     Uvicorn running on http://0.0.0.0:8082
```

Leave that terminal open.

The proxy needs to keep running.

---

## Step 6 · Test it

Open a second terminal.

Run:

```bash
ANTHROPIC_BASE_URL=http://localhost:8082 \
ANTHROPIC_API_KEY=freecc \
claude --bare -p "say hi"
```

You should get a reply in 5-30 seconds.

Owl Alpha is slow because it's free.

But it works.

If you got a reply: you're done.

---

## Step 7 · Make it default (optional)

Add these to your `~/.zshrc` or `~/.bashrc`:

```bash
export ANTHROPIC_BASE_URL=http://localhost:8082
export ANTHROPIC_API_KEY=freecc
```

Now every `claude` command uses Free Claude Code.

Reload your shell:

```bash
source ~/.zshrc
```

---

## ✅ You're done

The proxy is on `:8082`.

Claude CLI talks to it.

OpenRouter handles inference.

Zero cost.

If you want to swap models — edit `~/.fcc/.env` and restart `fcc-server`.

If you want to wire it into Agent OS — read `agent-os-wiring.md` next.

If something broke — read `troubleshooting.md` next.
