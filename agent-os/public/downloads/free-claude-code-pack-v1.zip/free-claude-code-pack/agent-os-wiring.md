# 🦉 Wiring Free Claude Code into Agent OS

You already built the proxy.

It's running on `:8082`.

Now let's plug it into the dashboard.

---

## 🔌 What this unlocks

A "Free Claude Code" agent in your sidebar.

Right next to Claude, OpenClaw, Hermes, Gemini, Antigravity.

Full chat panel.

History saved across page reloads.

Status pill showing the active upstream model.

One-click access from Mission Control.

---

## 📍 The files you need

Inside Agent OS:

- `src/lib/fcc.ts` — proxy probe + env vars
- `src/app/api/freeclaude/chat/route.ts` — streaming chat endpoint
- `src/app/api/fcc/route.ts` — status endpoint (GET + POST toggle)
- `src/components/FreeClaudePanel.tsx` — the chat UI
- `src/app/freeclaude/page.tsx` — the route page

If you cloned my Agent OS repo: all of these are already in place.

If you're building your own dashboard: copy them across.

---

## ⚡ Wire the sidebar

Open `src/components/Sidebar.tsx`.

Find the NAV array.

Add this entry after Antigravity:

```tsx
{
  href: "/freeclaude",
  label: "Free Claude Code",
  icon: <AgentAvatar agent="fcc" size={22} />,
  accent: "#10b981",
  dim: "rgba(16,185,129,0.16)"
},
```

Also add `/freeclaude` to the `agentRoutes` Set in the same file.

---

## 🎨 Add the agent avatar

Open `src/components/AgentAvatar.tsx`.

Add `"fcc"` to the `AgentKey` type.

Add a `fcc` entry to the `STYLE` object.

(Use any glyph. An owl works. So does a coin.)

---

## 🔐 Critical — the auth trick

The Claude CLI uses OAuth from your keychain by default.

That overrides `ANTHROPIC_API_KEY`.

So your env vars get ignored.

You'll see 401 errors in fcc-server's logs.

**The fix:** add `--bare` to the claude command.

`--bare` tells Claude: ignore OAuth, use env vars only.

Without `--bare`, Free Claude Code returns "API Error: empty or malformed response".

With `--bare`, it works.

This was the single biggest gotcha during build.

Now you know.

---

## 🧪 Test it

Restart your Next.js dev server:

```bash
npm run dev
```

Open the dashboard.

Click `Free Claude Code` in the sidebar.

You'll see:
- Status pill: `LIVE` (green)
- Model pill: `OWL-ALPHA · OPENROUTER`
- Empty welcome screen with setup links

Type `say hi`.

Press `⌘+Enter`.

Wait 10-30 seconds.

You should get a reply.

---

## 🧠 How memory works

Owl Alpha doesn't have native conversation memory.

Each `claude -p` call is single-turn.

So I pack the whole conversation into every request.

You'll see it as `history: ChatMsg[]` in `/api/freeclaude/chat/route.ts`.

`buildPromptWithHistory()` formats it as:

```
The following is the prior conversation...
User: hello
Assistant: hi
User: [new prompt]
Assistant:
```

Capped at 8KB / 24 turns.

Old turns drop off the front.

Localstorage holds the visual history across reloads.

---

## 🚪 If you want it always available

Start fcc-server on boot.

Add this to your `~/.zshrc`:

```bash
if ! curl -sf -o /dev/null http://127.0.0.1:8082/health; then
  nohup fcc-server > /tmp/fcc.log 2>&1 &
  disown
fi
```

Or use `launchctl` on macOS for a proper background service.

(Beyond scope of this guide — search `launchctl plist fcc-server` if you want that.)

---

## 🐛 If chat breaks after a model change

Edit `~/.fcc/.env`.

Restart fcc-server (`./start-fcc.sh --stop && ./start-fcc.sh --bg`).

Refresh the dashboard.

The status pill will pick up the new model automatically.

---

## ✅ Done

You have Free Claude Code in your dashboard.

Right next to your other agents.

Click → type → reply.

Zero cost per token.

If you build a slick UI for it, tag me when you ship.
