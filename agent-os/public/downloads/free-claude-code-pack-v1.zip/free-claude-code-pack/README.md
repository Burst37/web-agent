# 🦉 Free Claude Code — AI Profit Boardroom edition

The full Claude Code experience.

Without the Anthropic bill.

Run it through OpenRouter's free Owl Alpha model instead.

Same CLI. Same speed (almost). Same vibe.

---

## ⚡ What this gives you

A local proxy on your machine.

The proxy pretends to be Anthropic.

So `claude` just works.

But every request goes to OpenRouter.

Pick any model. Free or paid. Your choice.

Default = Owl Alpha. 1M context. Zero cost.

---

## 🎯 Why you want this

Anthropic API costs add up fast.

$15/M output tokens on Sonnet.

Run Claude Code all day, you're at $50+ a week.

Free Claude Code = $0 forever.

Same `claude` command in your terminal.

Same Claude Code in your IDE.

Same answers. Free.

---

## 📦 What's in this pack

`README.md` — what you're reading.

`INSTALL.md` — copy-paste setup steps.

`env.template` — your config file. Paste your OpenRouter key in.

`start-fcc.sh` — launches the proxy in one click.

`agent-os-wiring.md` — how to plug it into the Agent OS dashboard.

`troubleshooting.md` — every error I hit + the fix.

---

## ⏱️ Setup time

10 minutes if you have Homebrew.

15 minutes if you don't.

Run the steps in `INSTALL.md` in order.

You'll know it works when the terminal says `fcc-server running`.

---

## 🪙 Cost breakdown

Free Claude Code itself: free. Open source.

OpenRouter Owl Alpha: free. No card needed.

Faster paid models: 10x cheaper than Anthropic.

Net = you save 90%+ on Claude Code.

---

## 🛠️ How it works

You install `fcc-server` from GitHub.

It runs on port 8082.

You set 2 env vars when you launch Claude:

  ANTHROPIC_BASE_URL=http://localhost:8082
  ANTHROPIC_API_KEY=freecc

Claude CLI sends requests to your local proxy.

Proxy forwards to OpenRouter.

OpenRouter routes to whichever model you picked.

Response streams back. Same shape Claude expects.

You never see the difference.

---

## 📺 In Agent OS

Open the dashboard.

Click `Free Claude Code` in the left sidebar.

It's a full chat panel.

History saved across reloads.

Owl Alpha takes ~10-30 seconds per reply (it's free, be patient).

Swap to a faster model anytime by editing `~/.fcc/.env`.

---

## 🤝 Share this

The whole pack is yours.

Drop it in your own community.

Tag me when you do.

The more devs we save from Anthropic bills, the better.

— Julian
