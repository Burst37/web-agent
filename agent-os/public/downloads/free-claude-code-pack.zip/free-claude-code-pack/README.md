# 🦉 Free Claude Code — AI Profit Boardroom edition (v2)

The full Claude Code experience.

Without the Anthropic bill.

Plus a Workspace preview tab. Plus persistent chat history. Plus HyperFrames support.

---

## ⚡ What this gives you

A local proxy on your machine.

The proxy pretends to be Anthropic.

So `claude` just works.

But every request routes to OpenRouter / NVIDIA NIM / Kimi / Z.ai / whatever you pick.

Default = Owl Alpha. 1M context. Zero cost.

---

## 🆕 What's new in v2

**Workspace tab** — anything claude writes during a chat lands in `~/freeclaude-scratch/<project>/`. Browse + preview inline.

**HTML pages** render in a live iframe with Preview / Source toggle.

**Images / videos / audio** play inline. HyperFrames .mp4 / .webm renders work too.

**Per-project active toggle** — pick which scratch project the next chat will write into.

**Persistent chat history** — every conversation saves to localStorage. Survives reloads, browser restarts, tab switches.

**Smart parser** — uses streaming deltas as the source of truth, doesn't double-count the final assistant message.

**Elapsed counter** — shows how long the model has been thinking. After 5 seconds, hints that Owl Alpha can be slow.

---

## 🎯 Why you want this

Anthropic Claude direct: $15/M output tokens.

Run Claude Code all day, you're at $50+ a week.

Free Claude Code with Owl Alpha: $0 forever.

Same `claude` command. Same Claude Code interface in Agent OS.

Save 90%+ on Claude bills.

---

## 📦 What's in this pack

`README.md` → this file.

`INSTALL.md` → setup from zero.

`env.template` → drop into `~/.fcc/.env` and paste your OpenRouter key.

`start-fcc.sh` → one-click launcher with --bg, --stop, --status flags.

`agent-os-wiring.md` → how to plug Free Claude Code into the Agent OS dashboard.

`workspace-pattern.md` → how the preview tab works.

`hyperframes-workflow.md` → build + preview videos inline.

`troubleshooting.md` → every error + the fix.

`code-snippets/` → the actual TypeScript files that wire Free Claude Code into Agent OS.

---

## ⏱️ Setup time

10 minutes if you have Homebrew + Node.

15 minutes from a clean Mac.

Read INSTALL.md. Run the commands in order.

You'll know it works when the dashboard sidebar shows "Free Claude Code" with a green dot.

---

## 🪙 Cost breakdown

Free Claude Code itself: free. Open source.

OpenRouter Owl Alpha: free.

Faster paid models via OpenRouter: 10x cheaper than direct Anthropic.

Net: save 90%+ on Claude Code.

---

## 🤝 Share this

The whole pack is yours.

Drop it in your community.

Tag me when you do.

— Julian
