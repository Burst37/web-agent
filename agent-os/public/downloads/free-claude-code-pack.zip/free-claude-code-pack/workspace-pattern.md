# 📦 The Workspace tab

How it works.

How to use it.

How to extend it.

---

## 🎯 What you'll see

Inside Agent OS → `Free Claude Code` → two tabs at the top:

`[Chat]  [Workspace 3]`

The `3` is the count of scratch projects.

Click Workspace.

You'll see:

- Left sidebar: list of projects under `~/freeclaude-scratch/`
- Right pane: empty until you click a project
- A "new-project-name" input + Add button to create projects

---

## 🪄 The magic

When you chat in the Chat tab, the spawned `claude --bare` subprocess has its `cwd` pinned to the active project.

Anything Claude writes during the conversation lands in that project's folder.

Then the Workspace tab shows it.

The active project is the one with the green "active" badge.

Click "Set active →" on any other project to switch.

---

## 📁 Folder layout

```
~/freeclaude-scratch/
├── freeclaude-default/       (default — created on first chat)
│   ├── index.html
│   └── style.css
├── aipb-landing/             (you created this with "Add")
│   └── landing.html
└── hyperframes-explainer/    (created during a video build)
    ├── composition.html
    └── render.mp4
```

---

## 🖼️ What preview can do

Click any file in the right pane:

**HTML** → live iframe with [Preview] / [Source] toggle + "Open in new tab"

**Images** (.png .jpg .webp .svg .gif .avif) → render inline. Click to fullscreen.

**Videos** (.mp4 .webm .mov .m4v) → play with full scrub controls. HyperFrames renders work natively.

**Audio** (.mp3 .wav .m4a .ogg) → audio player.

**PDFs** → embedded viewer.

**Text / code** → source view in mono font.

**Binary** → download link only.

Plus HTTP Range support so video scrubbing is smooth + large files don't lock the browser.

---

## 🛠️ Building things end-to-end

A real workflow you'll use a lot:

**1.** Switch to Workspace tab.

**2.** Click "Add" with a project name like `aipb-landing`.

**3.** It becomes the active project (green pill in the header).

**4.** Switch to Chat tab.

**5.** Type:

> "Build a single-file HTML sales page for AI Profit Boardroom. Strong headline, three bullet points on what members get, big CTA button to skool.com/ai-profit-boardroom, footer with my name. Use Tailwind via CDN. Save to index.html."

**6.** Hit ⌘+Enter.

**7.** Wait ~30 seconds.

**8.** Switch back to Workspace.

**9.** `index.html` is now in the project. Click it.

**10.** Click "Preview" → see the rendered page right there.

**11.** Click "New tab" if you want to see it full-screen.

**12.** Click "Save" if you want to download it for hosting.

That's the loop.

Chat → build → preview → ship.

---

## 🔒 Security

The preview endpoint hard-restricts to `~/freeclaude-scratch/<project>/`.

Path traversal blocked.

Iframe runs with `sandbox="allow-scripts allow-forms allow-popups allow-modals"` — scripts work but can't read your dashboard's cookies.

You're safe to render AI-generated HTML.

---

## 🎨 Customising the scratch root

Default is `~/freeclaude-scratch/`.

To change it:

```bash
export AGENTIC_OS_FCC_SCRATCH="/path/to/your/scratch"
```

Add to your `~/.zshrc` to make it permanent.

Restart `npm run dev`.

---

## 🐛 Troubleshooting

**Workspace shows no projects**

You haven't chatted yet. Send a message in Chat tab → it auto-creates `freeclaude-default`.

**HTML preview is blank**

Owl Alpha sometimes writes wrong-looking HTML. Click "Source" to see what claude actually wrote. Click "New tab" to see browser dev tools.

**Video won't play**

Browser doesn't support the codec. Try a different output format (.webm vs .mp4).

**Files I expected aren't there**

Check the active-project pill in the top-right of the FCC page. If it's pointed at a different project, Claude is writing there instead.
