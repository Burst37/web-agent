# 🎬 HyperFrames workflow with Free Claude Code

Build video compositions.

Render them to .mp4.

Preview them inline.

All from one chat.

---

## 🎯 What HyperFrames is

A tool for building video compositions in HTML.

You write HTML + CSS + JS for each scene.

`hyperframes render` turns it into an MP4.

Free Claude Code can drive it for you.

---

## 📥 Setup (one-time)

Install HyperFrames globally:

```bash
npm install -g hyperframes
hyperframes doctor
```

Make sure the doctor command passes. Fix anything it warns about.

---

## ⚡ The workflow

Open Agent OS → `Free Claude Code` → `Workspace` tab.

Click "Add" with project name `hyperframes-explainer` (or whatever).

It becomes active.

Switch to Chat.

Type:

> "Use the hyperframes CLI to create a 10-second explainer video for AI Profit Boardroom.
>
> Scene 1 (3s): hero text 'Stop Tinkering With AI' with subtle zoom-in.
> Scene 2 (3s): three pricing tiers slide up from the bottom.
> Scene 3 (4s): final CTA 'Join AIPB' with a pulse animation.
>
> Background: dark with warm gradient.
> Font: bold sans-serif.
> Save composition to composition.html.
> Render to render.mp4 at 1920x1080."

Hit ⌘+Enter.

Wait.

---

## 👀 What happens

Free Claude Code:

1. Reads the project's `cwd` (your `hyperframes-explainer` dir)
2. Runs `hyperframes init` if needed
3. Writes `composition.html` with your scenes
4. Runs `hyperframes render --out render.mp4`
5. The .mp4 lands in the same dir

Switch back to Workspace.

Click `render.mp4`.

It plays in the dashboard.

Full controls. Scrub bar. Fullscreen.

---

## 🔄 Iterating

Don't like the first cut?

Stay in Chat.

Type:

> "The pulse on the CTA is too fast. Slow it to 1.5s per beat. Re-render."

Free Claude Code edits `composition.html` + re-runs `hyperframes render`.

Refresh the workspace.

Click render.mp4 again → new version plays.

This is the loop.

Iterate in chat. Preview in workspace.

---

## 🎨 What I use this for

- Twitter/X promo clips (~6 seconds)
- YouTube intros (~5 seconds)
- Loom-style explainers (~30-60 seconds)
- Sales page hero animations
- Email open animations

Anything where I'd otherwise use After Effects + spend 30 minutes per render.

Free Claude Code + HyperFrames knocks that down to ~3 minutes per draft.

---

## 🪙 Cost

HyperFrames: free (open source).

Free Claude Code: free (zero per-token cost via OpenRouter).

Net cost to produce a video: $0.

---

## 🐛 Common issues

**`hyperframes` command not found**

The npm install didn't pick up the global path. Try:

```bash
npm install -g hyperframes --force
which hyperframes
```

**Render fails with "no display"**

HyperFrames needs Chrome installed. Make sure it's in /Applications/.

**Render takes forever**

10-second video = ~30 seconds to render typically. If it's longer, the composition is heavy. Simplify.

**Audio doesn't play in the preview**

Browsers block autoplay with sound. Click the play button manually. Once you interact, audio works.

---

## ✅ The promise

Ask in plain English.

Get a working video.

Preview it in your dashboard.

No timeline editor. No render queue. No subscription.
