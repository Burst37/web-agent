# 🐛 Codex troubleshooting

Every error I hit + the fix.

---

## ❌ Chat returns "(no output)"

Cause: parser is checking the wrong event shape.

The real Codex `--json` event format is:

```json
{"type":"item.completed","item":{"type":"agent_message","text":"…actual reply…"}}
```

NOT `agent_message_delta`, NOT `task_complete`, NOT `result`.

Fix: in `CodexView.tsx`, the parser should look for:

```ts
if (evt.type === "item.completed" && evt.item?.type === "agent_message" && typeof evt.item.text === "string") {
  if (!sawDeltas) { acc = evt.item.text; setPartial(acc); }
}
```

That's the only shape Codex emits for assistant text.

---

## ❌ Workspace tab is empty

Cause: Codex ran in the wrong cwd, so the files landed somewhere outside `~/codex-scratch/`.

Fix: in `src/app/api/codex/chat/route.ts`, make sure the spawn pins `cwd`:

```ts
const cwd = await ensureCodexProject(body.project ?? "codex-default");
const child = spawnStream("codex", [...args], { cwd });
```

Every chat will now create the project dir if missing + write files there.

---

## ❌ Goal Mode log looks like raw JSON garbage

Cause: you skipped the `GoalLogStream.tsx` component.

The log is `codex exec --json` output. It needs parsing.

Fix: copy `GoalLogStream.tsx` from `code-snippets/`. Then in `CodexView.tsx` replace the `<pre>{openGoalLog}</pre>` with:

```tsx
<GoalLogStream log={openGoalLog} running={goal.status === "running"} />
```

---

## ❌ "Reading additional input from stdin..." then nothing happens

Cause: Codex thinks stdin is piped + waits for input.

Not actually a bug — the message is just noise. Wait ~30 seconds for the actual response.

If it never arrives, check the goal log file at `~/.agentic-os/codex-goal-logs/<goal-id>.log` for the real error.

---

## ❌ "failed to load skill /Users/.../SKILL.md: invalid YAML"

Cause: one of your Codex skill files has bad frontmatter.

Find the file, fix the YAML (usually a missing quote or colon).

Doesn't block Codex from working — it just skips that one skill.

---

## ❌ Sessions tab shows nothing

Cause: either you have no past sessions, OR `~/.codex/session_index.jsonl` is missing.

Run `codex` once in your terminal to create some sessions.

Then refresh the Sessions tab.

---

## ❌ Can't preview session files

Cause: the file is outside `$HOME`.

The session-file endpoint hard-restricts to under `$HOME` for security.

If your session ran in `/tmp` or `/var`, those files aren't browseable.

Fix: re-run the session with cwd inside `~/`.

---

## ❌ Goal doesn't start when I click "Launch goal"

Cause: probably an error spawning Codex. Check `/tmp/aos-dev.log` for the actual error.

Most likely: missing `--full-auto` permission. Make sure your Codex CLI has been used at least once interactively to grant the permissions.

---

## ❌ "Stop" button on a goal doesn't actually stop it

Cause: the child PID was lost (often because Next.js dev server restarted).

The goal status will say "stopped" but the underlying `codex exec` process may still be running.

Fix:
```bash
pkill -f "codex exec"
```

That kills any orphaned Codex processes.

---

## 🆘 Still stuck

Open an issue on the Agent OS repo.

Or message me in AI Profit Boardroom.

Include:
- What you tried
- The error message
- `tail -50 /tmp/aos-dev.log`
- `tail -50 ~/.agentic-os/codex-goal-logs/<goal-id>.log` (if Goal Mode)

I'll get back within a day.

— Julian
