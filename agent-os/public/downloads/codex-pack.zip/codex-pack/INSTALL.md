# 🛠️ Install — Codex inside Agent OS

Six steps. Order matters.

Assumes you already have Agent OS running. If not, set that up first.

---

## Step 1 · Install the Codex CLI

```bash
npm install -g @openai/codex
codex --version
```

Should print `codex-cli 0.125.0` or higher.

---

## Step 2 · Authenticate

```bash
codex login
```

Browser opens. Sign in with your ChatGPT account.

Tokens save to `~/.codex/auth.json`.

Test it:

```bash
codex exec --skip-git-repo-check "say hi"
```

You should get a reply.

---

## Step 3 · Wire the dashboard

In your Agent OS repo, copy these files from `code-snippets/`:

- `src/lib/codexWorkspace.ts` → workspace + sessions parser
- `src/lib/codexGoals.ts` → goal persistence + process tracking
- `src/components/CodexView.tsx` → the 4-tab agent surface
- `src/components/GoalLogStream.tsx` → the parsed event timeline
- `src/app/codex/page.tsx` → the route
- `src/app/api/codex/chat/route.ts` → streaming chat
- `src/app/api/codex/goals/route.ts` → list/create/stop/delete goals
- `src/app/api/codex/sessions/route.ts` → list past sessions
- `src/app/api/codex/session/route.ts` → single session detail
- `src/app/api/codex/session-file/[...path]/route.ts` → file preview for sessions
- `src/app/api/codex/workspace/route.ts` → projects list
- `src/app/api/codex/workspace/file/route.ts` → file text content
- `src/app/api/codex/preview/[...path]/route.ts` → iframe preview for workspace files

---

## Step 4 · Update the shared files

**`src/lib/config.ts`** — add `codex` to the agent list.

```ts
export interface AgenticConfig {
  // ...existing
  codex: string | null;
}

export const config: AgenticConfig = {
  // ...existing
  codex: process.env.AGENTIC_OS_CODEX_BIN ?? fileCfg.codex ?? which("codex"),
};
```

**`src/lib/runner.ts`** — add `"codex"` to `AgentName`:

```ts
export type AgentName = "claude" | "openclaw" | "hermes" | "gemini" | "antigravity" | "fcc" | "codex";
```

**`src/components/AgentAvatar.tsx`** — add the Codex avatar entry (rosette glyph + emerald gradient). See snippet in `code-snippets/AgentAvatar-addition.tsx.snippet`.

**`src/components/Sidebar.tsx`** — add the sidebar entry between Antigravity and Free Claude Code:

```tsx
{ href: "/codex", label: "Codex", icon: <AgentAvatar agent="codex" size={22} />, accent: "#22c55e", dim: "rgba(34,197,94,0.16)" },
```

And add `/codex` to the `agentRoutes` Set.

**`src/components/TopBar.tsx`** — add the Codex roman numeral + title entry:

```ts
"/codex": { numeral: "VII.", label: "Agent · Codex", title: "Codex", sub: "OpenAI's coding agent. Chat, set long-running goals, preview anything it builds." },
```

(Renumber the agents below Codex if needed.)

---

## Step 5 · Restart the dev server

```bash
cd ~/Agentic\ OS/agentic-os
npm run dev
```

Important: restart, don't just refresh. Turbopack's module cache needs to pick up the new files.

---

## Step 6 · Test it

Open `http://localhost:3737/codex`.

You should see:

- `VII. ─── AGENT · CODEX` eyebrow at the top
- "Codex" page title in Bricolage
- Four tabs: Chat, Goal Mode, Sessions, Workspace
- The Sessions tab pre-populated with every past Codex session

Type a message in Chat → get a reply.

Click Sessions → click any past session → see the transcript + files.

Click Goal Mode → write a goal → launch it → watch the live timeline.

If anything breaks, read `troubleshooting.md`.

---

## ✅ Done

Codex is now a first-class citizen in your Agent OS.

Use it however you'd use the terminal Codex — just prettier.
