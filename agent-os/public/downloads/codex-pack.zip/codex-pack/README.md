# 🌀 Codex — AI Profit Boardroom edition

OpenAI's coding agent.

Wired into Agent OS alongside Claude, Hermes, Gemini, Antigravity, Free Claude Code.

Chat. Set hours-long goals. Browse past sessions. Preview anything it builds.

---

## ⚡ What this gives you

**Chat tab** — quick exec via `codex exec --json`. Multi-turn memory. Same auth as terminal Codex.

**Goal Mode** — set a long-horizon objective. Codex runs `--full-auto` until done. Live timeline shows every command, message, web search. Walk away. Come back to a finished build.

**Sessions browser** — every Codex session you've ever run. Click one → see the full transcript + every file it touched. Images / videos / HTML render inline.

**Workspace** — projects Codex creates live in `~/codex-scratch/<project>/`. Click any file to preview.

---

## 🪙 Cost

Included with ChatGPT Pro.

Goal Mode runs can burn quota fast — keep an eye on it.

---

## 📦 What's in this pack

`README.md` → this file.

`INSTALL.md` → 6 steps to a working Codex tab inside Agent OS.

`troubleshooting.md` → every error I hit + the fix.

`workspace-pattern.md` → how the preview iframe works.

`code-snippets/` → the actual TypeScript files you need to copy into your dashboard.

---

## ⏱️ Setup

15 minutes if you already have Agent OS.

30 minutes if you're starting from zero.

Read `INSTALL.md`.

Run the commands in order.

You'll know it works when the sidebar shows `Codex` between Antigravity and Free Claude Code.

---

## 🤝 Share this

The whole pack is yours.

Hand it to your community.

Tag me when you ship.

— Julian
